#!/usr/bin/env python3

import sys
import os
import shutil
import requests

PROGRAM_DIR = sys.argv[1]
VERSION = sys.argv[2]

VERSION_LINKS = {
    '2020.2': 'https://mcreator.net/repository/2020-2/MCreator%202020.2%20Linux%2064bit.tar.gz',
    '2020.2-plugins': {},
    '2020.4': 'https://mcreator.net/repository/2020-4/MCreator%202020.4%20Linux%2064bit.tar.gz',
    '2020.4-plugins': {},
    '2020.5': 'https://github.com/MCreator/MCreator/releases/download/2020.5.47520/MCreator.2020.5.Linux.64bit.tar.gz',
    '2020.5-plugins': {
        'Mod-Checker': 'https://mcreator.net/system/files/2022-04/mod-checker.zip'
    },
    '2021.1': 'https://github.com/MCreator/MCreator/releases/download/2021.1.18117/MCreator.2021.1.Linux.64bit.tar.gz',
    '2021.1-plugins': {
        'More-Item-Triggers': 'https://mcreator.net/system/files/2022-09/MoreItemTriggers_0.zip',
        'Mod-Checker': 'https://mcreator.net/system/files/2022-04/mod-checker.zip',
        'Minecraft-Forge-1.12.2-Generator': 'https://mcreator.net/system/files/2021-04/mcreator-generator-1.12.2-2021.1-v4.0.1.zip'
    },
    '2021.2': 'https://github.com/MCreator/MCreator/releases/download/2021.2.36710/MCreator.2021.2.Linux.64bit.tar.gz',
    '2021.2-plugins': {
        'More-Item-Triggers': 'https://mcreator.net/system/files/2022-09/MoreItemTriggers_0.zip',
        'Mod-Checker': 'https://mcreator.net/system/files/2022-04/mod-checker.zip'
    },
    '2021.3': 'https://github.com/MCreator/MCreator/releases/download/2021.3.54000/MCreator.2021.3.Linux.64bit.tar.gz',
    '2021.3-plugins': {
        'File-Manager': 'https://mcreator.net/system/files/2022-11/file-manager.zip',
        'Key-Value-Plugin': 'https://mcreator.net/system/files/2022-10/map_7.zip',
        'More-Item-Triggers': 'https://mcreator.net/system/files/2022-09/MoreItemTriggers_0.zip',
        'Mod-Checker': 'https://mcreator.net/system/files/2022-04/mod-checker.zip',
        'JEI-API-Forge': 'https://mcreator.net/system/files/2022-03/jei-API.zip'
    },
    '2022.1': 'https://github.com/MCreator/MCreator/releases/download/2022.1.20510/MCreator.2022.1.Linux.64bit.tar.gz',
    '2022.1-plugins': {
        'HTTP-Utility': 'https://mcreator.net/system/files/2022-12/HTTP%20Utility-1.1.0.zip',
        'ShadowsAPIs': 'https://mcreator.net/system/files/2022-12/ShadowsAPIs_1_0_3_1.zip',
        'Array-List': 'https://mcreator.net/system/files/2022-10/arraylist.zip',
        'Chunk-Manager': 'https://mcreator.net/system/files/2022-09/chunk-manager.zip',
        'Goldfuscate-1.18.2': 'https://mcreator.net/system/files/2022-09/goldfuscate.zip',
        'All-Mods': 'https://mcreator.net/system/files/2022-10/all_mods-1.2.zip',
        'More-Item-Triggers': 'https://mcreator.net/system/files/2022-09/MoreItemTriggers_0.zip',
        'Entity-ID-&-UUID': 'https://mcreator.net/system/files/2022-07/entity-id-and-uuid.zip',
        'Mod-Checker': 'https://mcreator.net/system/files/2022-04/mod-checker.zip'
    },
    '2022.2': 'https://github.com/MCreator/MCreator/releases/download/2022.2.34517/MCreator.2022.2.Linux.64bit.tar.gz',
    '2022.2-plugins': {
        'HTTP-Utility': 'https://mcreator.net/system/files/2022-12/HTTP%20Utility-1.1.0.zip',
        'ShadowsAPIs': 'https://mcreator.net/system/files/2022-12/ShadowsAPIs_1_0_3_1.zip',
        'More-JSON-Procedures': 'https://mcreator.net/system/files/2022-11/More%20JSON%20Procedures-1.0.0.zip',
        'File-Manager': 'https://mcreator.net/system/files/2022-11/file-manager.zip',
        'Array-List': 'https://mcreator.net/system/files/2022-10/arraylist.zip',
        'Chunk-Manager': 'https://mcreator.net/system/files/2022-09/chunk-manager.zip',
        'Goldfuscate-1.18.2': 'https://mcreator.net/system/files/2022-09/goldfuscate.zip',
        'Attributes': 'https://mcreator.net/system/files/2022-10/attributes-2-2-6.zip',
        'Key-Value-Plugin': 'https://mcreator.net/system/files/2022-10/map_7.zip',
        '1.17.1-Generator': 'https://mcreator.net/system/files/2022-10/generator-1.17.1.zip',
        'Kleiders-Custom-Renderer': 'https://mcreator.net/system/files/2022-10/Kleiders%20Custom%20Renderer%20Plugin%204.0.5.zip',
        'More-Item-Triggers': 'https://mcreator.net/system/files/2022-09/MoreItemTriggers_0.zip',
        'Entity-ID-&-UUID': 'https://mcreator.net/system/files/2022-07/entity-id-and-uuid.zip'
    },
    '2022.3': 'https://github.com/MCreator/MCreator/releases/download/2022.3.48217/MCreator.2022.3.Linux.64bit.tar.gz',
    '2022.3-plugins': {
        'HTTP-Utility': 'https://mcreator.net/system/files/2022-12/HTTP%20Utility-1.1.0.zip',
        'More-JSON-Procedures': 'https://mcreator.net/system/files/2022-11/More%20JSON%20Procedures-1.0.0.zip',
        '1.16.5-Generator': 'https://mcreator.net/system/files/2022-11/MCreator%201.16.5%20Generator%20Plugin%20v1.3.2.zip',
        'File-Manager': 'https://mcreator.net/system/files/2022-11/file-manager.zip',
        'Array-List': 'https://mcreator.net/system/files/2022-10/arraylist.zip',
        'Nerdy\'s-GeckoLib': 'https://mcreator.net/system/files/2022-12/Nerdys_Geckolib_Plugin_4.zip'
    }
}

url: str
plugin_url: dict


class ProgressBar:

    def __init__(self, expected_length: float, fill_char: str = '=', width: int = 10, label: str = ''):
        self._expected_length = expected_length
        self._width = width
        self._fill_char = fill_char
        self._label = label
        self._progress = 0
        self._done = False
        print(self._compile_string(0), end='')

    def update(self, progress: float):
        self._progress += progress
        quotient = self._progress / self._expected_length
        percent = quotient * 100
        if self._done is False:
            print(self._compile_string(int(percent)), end='')

    def _compile_string(self, percentage: int):
        if percentage > 100:
            percentage = 100
        length_of_char = 100 / self._width
        char_percentage = percentage
        char_count = 0
        while char_percentage > length_of_char:
            char_percentage -= length_of_char
            char_count += 1
        string = f'\r{self._label} ['
        if percentage == 100:
            self._done = True
            char_count = self._width
        for _ in range(char_count):
            string += self._fill_char
        for _ in range((self._width - char_count)):
            string += ' '
        string += f'] {percentage}%'
        if len(string) > os.get_terminal_size()[0]:
            string = string[:os.get_terminal_size()[0]]
        if self._done is True:
            string += '\n'
        return string


def download(file_url: str, dst: str, label: str = 'Downloading'):
    try:
        label += ' '
        r = requests.get(file_url, stream=True)
        with open(dst, 'wb') as f:
            bar = ProgressBar(int(r.headers.get('content-length')), label=label, width=20)
            for chunk in r.iter_content(1024):
                if chunk:
                    f.write(chunk)
                    f.flush()
                    bar.update(1024)
    except Exception:
        sys.exit(f'ERR: error downloading mcreator {VERSION}')


def get_urls():
    global url, plugin_url
    found = False
    for key, value in VERSION_LINKS.items():
        if VERSION == key:
            url = value
            plugin_url = VERSION_LINKS[f'{key}-plugins']
            found = True
            break
    if found is False:
        sys.exit('no version found')


def download_content():
    download(url, os.path.join(PROGRAM_DIR, 'mcreator.tar.gz'), label=f'Downloading mcreator {VERSION}')
    print('Extracting mcreator.tar.gz...')
    shutil.unpack_archive(os.path.join(PROGRAM_DIR, 'mcreator.tar.gz'), PROGRAM_DIR, 'tar')
    dir_name = os.listdir(os.path.join(PROGRAM_DIR))[0]
    print('Downloading plugins...')
    for key, value in plugin_url.items():
        download(value, os.path.join(PROGRAM_DIR, dir_name, 'plugins', key), label=f'Downloading {key}')
    return dir_name


def cleanup():
    os.remove(os.path.join(PROGRAM_DIR, 'mcreator.tar.gz'))


if __name__ == '__main__':
    success = True
    get_urls()
    print('Downloading files...')
    download_content()
    print('Cleaning up...')
    cleanup()



