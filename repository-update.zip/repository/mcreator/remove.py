#!/usr/bin/env python3

import shutil
import os
import sys


PROGRAM_DIR = sys.argv[1]
VERSION = sys.argv[2]


def uninstall():
    print(f'Removing mcreator {VERSION}...')
    shutil.rmtree(os.path.join(PROGRAM_DIR, os.listdir(PROGRAM_DIR)[0]))


if __name__ == '__main__':
    try:
        uninstall()
    except Exception:
        pass

