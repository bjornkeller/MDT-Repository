
print('true', end='')
