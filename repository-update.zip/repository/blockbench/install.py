#!/usr/bin/env python3
import subprocess
import sys
import os
import shutil
import requests

PROGRAM_DIR = sys.argv[1]
VERSION = sys.argv[2]

VERSION_LINK = 'https://github.com/JannisX11/blockbench/releases/download/v4.5.2/Blockbench_4.5.2.AppImage'


class ProgressBar:

    def __init__(self, expected_length: float, fill_char: str = '=', width: int = 10, label: str = ''):
        self._expected_length = expected_length
        self._width = width
        self._fill_char = fill_char
        self._label = label
        self._progress = 0
        self._done = False
        print(self._compile_string(0), end='')

    def update(self, progress: float):
        self._progress += progress
        quotient = self._progress / self._expected_length
        percent = quotient * 100
        if self._done is False:
            print(self._compile_string(int(percent)), end='')

    def _compile_string(self, percentage: int):
        if percentage > 100:
            percentage = 100
        length_of_char = 100 / self._width
        char_percentage = percentage
        char_count = 0
        while char_percentage > length_of_char:
            char_percentage -= length_of_char
            char_count += 1
        string = f'\r{self._label} ['
        if percentage == 100:
            self._done = True
            char_count = self._width
        for _ in range(char_count):
            string += self._fill_char
        for _ in range((self._width - char_count)):
            string += ' '
        string += f'] {percentage}%'
        if len(string) > os.get_terminal_size()[0]:
            string = string[:os.get_terminal_size()[0]]
        if self._done is True:
            string += '\n'
        return string


def download(file_url: str, dst: str, label: str = 'Downloading'):
    try:
        label += ' '
        r = requests.get(file_url, stream=True)
        with open(dst, 'wb') as f:
            bar = ProgressBar(int(r.headers.get('content-length')), label=label, width=20)
            for chunk in r.iter_content(1024):
                if chunk:
                    f.write(chunk)
                    f.flush()
                    bar.update(1024)
    except Exception:
        sys.exit(f'ERR: error downloading mcreator {VERSION}')


def download_content():
    download(VERSION_LINK, os.path.join(PROGRAM_DIR, 'Blockbench_4.5.2.AppImage'), label=f'Downloading blockbench {VERSION}')
    subprocess.call(['chmod', '+x', os.path.join(PROGRAM_DIR, 'Blockbench_4.5.2.AppImage')])


if __name__ == '__main__':
    print('Downloading files...')
    download_content()
    print('Done!')



