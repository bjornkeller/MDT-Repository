#!/usr/bin/env python3

import os
import sys
import subprocess
import time


PROGRAM_DIR = sys.argv[1]
VERSION = sys.argv[2]


def start():
    print(f'Starting blockbench {VERSION}...')
    pid = os.fork()
    if pid > 0:
        time.sleep(1)
        sys.exit(0)
    subprocess.call([os.path.join(os.path.abspath(PROGRAM_DIR), 'Blockbench_4.5.2.AppImage')], cwd=PROGRAM_DIR)


if __name__ == '__main__':
    start()
